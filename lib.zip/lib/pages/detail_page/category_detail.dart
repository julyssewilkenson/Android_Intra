import 'package:flutter/material.dart';
import 'package:testentra/pages/payment_page.dart';

import 'package:testentra/utils.dart';
import 'package:testentra/_widget/_widget_product.dart';
import 'package:testentra/service/api_service.dart';

class CategoryDetail extends StatelessWidget {
  final String category;
  const CategoryDetail({super.key, required this.category});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(category),
        actions: [
          TextButton(
              onPressed: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const PayementPage()));
              },
              child: const Text(
                "PEYE",
                style: UtilsTheme.titleHead, //UtilsTheme est defini dans le fichier utils.dart
                // et est utilise pr definir le style de texte, pour les titres de l'appliction
              ))
        ],
      ),
      body: SingleChildScrollView(
          child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text(category, style: UtilsTheme.detailCategoryTitle),
          ),
          ProductListWidget(getProducts: () {
            return APIService.getProductsByCategory(category);
          }),
        ],
      )),
    );
  }
}
