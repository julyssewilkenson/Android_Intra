import 'package:flutter/material.dart';
import 'package:testentra/utils.dart';
import 'package:testentra/_widget/_widget_product.dart';
import 'package:testentra/storage/storage.dart';
import 'package:provider/provider.dart';

class CartPage extends StatelessWidget {
  const CartPage({super.key});

  @override
  Widget build(BuildContext context) {
    StateNotifier state = context.watch<StateNotifier>();
    //pour accéder à l'instance du StateNotifier et obtenir l'état actuel de l'application.
    if (state.isLogin()) {
      return ProductListWidget(getProducts: () {
        return Storage.getListCartsProduct(state.getUser()['id']);
      });
    } else {
      return ProductListWidget(getProducts: () {
        return Storage.getListCartsProduct(-1);
      });
    }
  }
}
