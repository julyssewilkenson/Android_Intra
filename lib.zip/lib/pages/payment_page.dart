import 'package:flutter/material.dart';

class PayementPage extends StatelessWidget {
  const PayementPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Center(child: Text("Payment Page"))),
      body: Container(
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(20)),
        child: Column(
          children: [
            Row(
              children: [
                const Text("Payment par monCash"),
                const Spacer(),
                Expanded(
                  child: Center(
                    child: Image.asset(
                      "moncash.png",
                      height: 120,
                    ),
                  ),
                ),
                const SizedBox(
                  height: 12,
                ),
              ],
            ),
            // SizedBox(height: 10),
            Row(
              children: [
                const Text("Payment par NatCash"),
                const Spacer(),
                Expanded(
                  child: Center(
                    child: Image.asset(
                      "natcash.png",
                      height: 120,
                    ),
                  ),
                ),
                const SizedBox(
                  height: 12,
                ),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                const Text("Payment par carte bancaire"),
                const Spacer(),
                Expanded(
                  child: Center(
                    child: Image.asset(
                      "master.png",
                      height: 120,
                    ),
                  ),
                ),
                const SizedBox(
                  height: 12,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
