import 'dart:convert';

class Article {
  final int id;
  final String title;
  final String price;
  final String description;
  final String image;
  final String category;

  Article(
      {required this.id,
      required this.title,
      required this.price,
      required this.category,
      required this.description,
      required this.image});

  factory Article.fromJson(Map<String, dynamic> jsonData) {
    return Article(
      id: jsonData['id'],
      title: jsonData['title'],
      price: jsonData['price'].toString(),
      description: jsonData['description'],
      image: jsonData['image'],
      category: jsonData['category'],
    );
  }
}

class Category {
  String? name;

  Category({this.name});

  factory Category.fromJson(String json) {
    return Category(name: json);
  }
}

class User {
  int id;
  String username;

  User(
    this.id,
    this.username,
  );

  factory User.fromMap(Map<String, dynamic> map) {
    return User(
      map['id'],
      map['username'],
    );
  }

  factory User.fromJson(String json) {
    final Map<String, dynamic> map = jsonDecode(json);
    return User.fromMap(map);
  }
}
